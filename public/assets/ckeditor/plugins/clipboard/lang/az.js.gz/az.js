/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'clipboard', 'az', {
	copy: 'Köçür',
	copyError: 'Avtomatik köçürülməsi mümkün deyil. Ctrl+C basın.',
	cut: 'Kəs',
	cutError: 'Avtomatik kəsmə mümkün deyil. Ctrl+X basın.',
	paste: 'Əlavə et',
	pasteNotification: 'Sizin İnternet bələdçisi bu cür mətnin köçürməsi dəstəklənmir. Əlavə etmək üçün %1 basın.'
} );
