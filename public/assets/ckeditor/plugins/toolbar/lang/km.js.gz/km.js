/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'toolbar', 'km', {
	toolbarCollapse: 'បង្រួម​របារ​ឧបករណ៍',
	toolbarExpand: 'ពង្រីក​របារ​ឧបករណ៍',
	toolbarGroups: {
		document: 'ឯកសារ',
		clipboard: 'Clipboard/មិន​ធ្វើ​វិញ',
		editing: 'ការ​កែ​សម្រួល',
		forms: 'បែបបទ',
		basicstyles: 'រចនាបថ​មូលដ្ឋាន',
		paragraph: 'កថាខណ្ឌ',
		links: 'តំណ',
		insert: 'បញ្ចូល',
		styles: 'រចនាបថ',
		colors: 'ពណ៌',
		tools: 'ឧបករណ៍'
	},
	toolbars: 'របារ​ឧបករណ៍​កែ​សម្រួល'
} );
