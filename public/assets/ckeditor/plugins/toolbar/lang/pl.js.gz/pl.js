/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'toolbar', 'pl', {
	toolbarCollapse: 'Zwiń pasek narzędzi',
	toolbarExpand: 'Rozwiń pasek narzędzi',
	toolbarGroups: {
		document: 'Dokument',
		clipboard: 'Schowek/Wstecz',
		editing: 'Edycja',
		forms: 'Formularze',
		basicstyles: 'Style podstawowe',
		paragraph: 'Akapit',
		links: 'Hiperłącza',
		insert: 'Wstawianie',
		styles: 'Style',
		colors: 'Kolory',
		tools: 'Narzędzia'
	},
	toolbars: 'Paski narzędzi edytora'
} );
